# -*- coding: utf-8 -*-
"""
Character Cast Images v5 — TVDB API Only
Monitors content changes. Fetches character images from TVDB.
Writes them to local files the skin reads directly.
"""

import re
import xbmc
import xbmcaddon
import xbmcgui

from resources.lib.tvdb_client import TVDBClient
from resources.lib.cache_manager import CacheManager


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[CharacterCast][Service] {}".format(msg), level)


class ContentMonitor:
    def __init__(self):
        self.addon = xbmcaddon.Addon("script.charactercast")
        self.cache = CacheManager()
        self._client = None
        self._current_id = None
        self._home = xbmcgui.Window(10000)

    @property
    def client(self):
        apikey = self.addon.getSetting("tvdb_apikey")
        if not apikey:
            return None
        pin = self.addon.getSetting("tvdb_pin") or ""
        if self._client is None or self._client.apikey != apikey:
            self._client = TVDBClient(apikey, pin)
        return self._client

    def _get_content_info(self):
        info = {"title": "", "year": "", "media_type": "", "imdb_id": "", "tmdb_id": ""}

        tmdb_type = self._home.getProperty("TMDbHelper.ListItem.Monitor.TMDb_Type") or ""
        tmdb_id = self._home.getProperty("TMDbHelper.ListItem.Monitor.TMDb_ID") or ""

        if tmdb_type and tmdb_id:
            info["tmdb_id"] = tmdb_id
            info["media_type"] = "series" if tmdb_type == "tv" else "movie"
            info["title"] = (
                self._home.getProperty("TMDbHelper.ListItem.TVShow.Title") or
                self._home.getProperty("TMDbHelper.ListItem.Title") or ""
            )
            info["imdb_id"] = self._home.getProperty("TMDbHelper.ListItem.IMDb_ID") or ""
            info["year"] = self._home.getProperty("TMDbHelper.ListItem.Year") or ""

        if not info["title"]:
            player = xbmc.Player()
            if player.isPlaying():
                try:
                    tag = player.getVideoInfoTag()
                    info["title"] = tag.getTVShowTitle() or tag.getTitle() or ""
                    info["year"] = str(tag.getYear()) if tag.getYear() else ""
                    info["imdb_id"] = tag.getIMDBNumber() or ""
                    if tag.getTVShowTitle() or tag.getMediaType() in ("episode", "tvshow", "season"):
                        info["media_type"] = "series"
                    else:
                        info["media_type"] = "movie"
                except Exception:
                    pass

        if not info["title"]:
            info["title"] = (
                xbmc.getInfoLabel("ListItem.TVShowTitle") or
                xbmc.getInfoLabel("ListItem.Title") or ""
            )
            info["year"] = xbmc.getInfoLabel("ListItem.Year") or ""
            info["imdb_id"] = xbmc.getInfoLabel("ListItem.IMDBNumber") or ""
            dbtype = xbmc.getInfoLabel("ListItem.DBType") or ""
            if dbtype in ("episode", "tvshow", "season"):
                info["media_type"] = "series"
            elif not info["media_type"]:
                info["media_type"] = "movie"

        info["title"] = re.sub(r"\s*\(\d{4}\)\s*$", "", info["title"]).strip()
        return info

    def _make_id(self, info):
        return "{}_{}_{}".format(info["media_type"], info["tmdb_id"] or info["title"], info["year"])

    def check_and_update(self):
        if not self.client:
            return

        info = self._get_content_info()
        if not info["title"] and not info["tmdb_id"]:
            return

        content_id = self._make_id(info)
        if content_id == self._current_id:
            return

        log("Content: '{}' ({}, tmdb={})".format(
            info["title"], info["media_type"], info.get("tmdb_id", "")))

        # Check cache
        local_mapping = self.cache.get_mapping(content_id)

        if local_mapping is None:
            local_mapping = {}
            tvdb_type = "series" if info["media_type"] == "series" else "movie"

            raw = self.client.get_character_images(
                info["title"],
                media_type=tvdb_type,
                year=info["year"] or None,
                imdb_id=info["imdb_id"] or None,
            )

            # Download each character image
            for actor_name, img_url in raw.items():
                local = self.cache.get_local_image(img_url)
                if local:
                    local_mapping[actor_name] = local

            self.cache.save_mapping(content_id, local_mapping)
            log("Cached {} images for '{}'".format(len(local_mapping), info["title"]))

        # Populate active directory
        if local_mapping:
            count = self.cache.populate_active(local_mapping)
            self._home.setProperty("charcast.active", "true")
            log("Active: {} character images ready".format(count))
        else:
            self.cache.clear_active()
            self._home.clearProperty("charcast.active")

        self._current_id = content_id

    def clear(self):
        self.cache.clear_active()
        self._current_id = None
        self._home.clearProperty("charcast.active")


class PlayerMonitor(xbmc.Player):
    def __init__(self, cm):
        super().__init__()
        self.cm = cm

    def onAVStarted(self):
        log("Playback started")
        xbmc.sleep(1500)
        self.cm._current_id = None
        self.cm.check_and_update()

    def onPlayBackStopped(self):
        self.cm.clear()

    def onPlayBackEnded(self):
        self.cm.clear()


class KodiMonitor(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.settings_changed = False

    def onSettingsChanged(self):
        self.settings_changed = True


def main():
    log("Service v5 starting (TVDB API)")

    addon = xbmcaddon.Addon("script.charactercast")
    if not addon.getSetting("tvdb_apikey"):
        log("No TVDB API key configured — waiting for settings")

    monitor = KodiMonitor()
    cm = ContentMonitor()
    player = PlayerMonitor(cm)
    home = xbmcgui.Window(10000)
    last_tmdb_id = ""

    while not monitor.abortRequested():
        if monitor.waitForAbort(2):
            break

        if monitor.settings_changed:
            monitor.settings_changed = False
            cm.addon = xbmcaddon.Addon("script.charactercast")
            cm._client = None  # Force re-auth with new key

        try:
            current_tmdb_id = home.getProperty("TMDbHelper.ListItem.Monitor.TMDb_ID") or ""
            if current_tmdb_id != last_tmdb_id:
                last_tmdb_id = current_tmdb_id
                if current_tmdb_id:
                    cm._current_id = None
                    cm.check_and_update()

            if player.isPlaying():
                cm.check_and_update()

        except Exception as e:
            log("Error: {}".format(e))

    cm.clear()
    home.clearProperty("charcast.active")
    log("Service stopped")


if __name__ == "__main__":
    main()
