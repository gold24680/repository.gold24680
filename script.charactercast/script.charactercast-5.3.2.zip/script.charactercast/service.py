# -*- coding: utf-8 -*-
"""
Character Cast Images v5 — Background Service
TVDB API v4 = primary; TVMaze = backup for series.
Character images written to: special://profile/addon_data/script.charactercast/active/actor name.jpg
Skin: $INFO[ListItem.Label,special://profile/addon_data/script.charactercast/active/,.jpg]
"""

import os
import re
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.tvmaze_client import TVMazeClient
from resources.lib.tvdb_client import TVDBClient
from resources.lib.cache_manager import CacheManager
from resources.lib.active_images import ActiveImageManager


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[CharacterCast][Service] {}".format(msg), level)


# Skin XML written to Includes_CharacterCast.xml in the active skin.
# Player.HasVideo gates character images to OSD-only; info/browse pages fall
# through to the normal $VAR[Image_Poster] (TMDb actor headshots).
_CHARCAST_XML = (
    '<?xml version="1.0" encoding="UTF-8"?>\n'
    '<includes>\n'
    '    <variable name="Image_Poster_CharCast">\n'
    '        <value condition="!String.IsEmpty(Window(Home).Property(charcast.active))'
    ' + Player.HasVideo">'
    '$INFO[ListItem.Label,special://profile/addon_data/script.charactercast/active/,.jpg]'
    '</value>\n'
    '        <value>$VAR[Image_Poster]</value>\n'
    '    </variable>\n'
    '</includes>\n'
)


def _update_skin_file():
    """
    Find Includes_CharacterCast.xml inside the active skin and update it if
    the content has changed. Creates the file if it doesn't exist yet.
    Returns True if the file was created or changed.
    """
    skin_id = xbmc.getSkinDir()
    if not skin_id:
        return False

    skin_path = xbmcvfs.translatePath("special://home/addons/{}/".format(skin_id))
    if not os.path.isdir(skin_path):
        log("Skin path not found: {}".format(skin_path), xbmc.LOGWARNING)
        return False

    target = None
    includes_dir = None
    for root, _dirs, files in os.walk(skin_path):
        if "Includes_CharacterCast.xml" in files:
            target = os.path.join(root, "Includes_CharacterCast.xml")
            break
        if "Includes.xml" in files and includes_dir is None:
            includes_dir = root

    if not target:
        if includes_dir:
            target = os.path.join(includes_dir, "Includes_CharacterCast.xml")
            log("Includes_CharacterCast.xml not found — will create at: {}".format(target))
        else:
            log("Could not find skin XML directory in '{}'".format(skin_id), xbmc.LOGWARNING)
            return False

    try:
        with open(target, "r", encoding="utf-8") as f:
            current = f.read()
        if current.strip() == _CHARCAST_XML.strip():
            log("Skin file already up to date")
            return False
    except (IOError, OSError):
        pass  # File doesn't exist yet — will create it

    try:
        with open(target, "w", encoding="utf-8") as f:
            f.write(_CHARCAST_XML)
        log("Updated skin Includes_CharacterCast.xml at: {}".format(target))
        return True
    except Exception as e:
        log("Failed to update skin file: {}".format(e), xbmc.LOGWARNING)
        return False


class ContentMonitor:
    def __init__(self):
        self.addon = xbmcaddon.Addon("script.charactercast")
        self.cache = CacheManager()
        self.tvmaze = TVMazeClient()
        self._tvdb_client = None
        self.active = ActiveImageManager()
        self._current_id = None
        self._playing = False
        self._home = xbmcgui.Window(10000)

    def _get_tvdb_client(self):
        if self._tvdb_client is None:
            key = self.addon.getSetting("tvdb_apikey") or ""
            self._tvdb_client = TVDBClient(key) if key else None
        return self._tvdb_client

    def _get_content_info(self):
        info = {
            "title": "", "year": "", "media_type": "", "imdb_id": "", "tmdb_id": "",
            "_from_player": False,
        }

        # 1. Player API — always tried first during playback; gives stable detection
        player = xbmc.Player()
        if player.isPlaying():
            try:
                tag = player.getVideoInfoTag()
                title = tag.getTVShowTitle() or tag.getTitle() or ""
                if title:
                    info["title"] = title
                    info["year"] = str(tag.getYear()) if tag.getYear() else ""
                    info["imdb_id"] = tag.getIMDBNumber() or ""
                    info["_from_player"] = True
                    try:
                        info["tmdb_id"] = tag.getUniqueID("tmdb") or ""
                    except Exception:
                        pass
                    if tag.getTVShowTitle() or tag.getMediaType() in ("episode", "tvshow", "season"):
                        info["media_type"] = "series"
                    else:
                        info["media_type"] = "movie"
            except Exception:
                pass

        # 2. TMDbHelper — used when not playing (browsing) or player has no metadata yet
        if not info["title"] and not info["tmdb_id"]:
            tmdb_type = self._home.getProperty("TMDbHelper.ListItem.Monitor.TMDb_Type") or ""
            tmdb_id = self._home.getProperty("TMDbHelper.ListItem.Monitor.TMDb_ID") or ""
            if tmdb_type and tmdb_id:
                info["tmdb_id"] = tmdb_id
                info["media_type"] = "series" if tmdb_type == "tv" else "movie"
                info["title"] = (
                    self._home.getProperty("TMDbHelper.ListItem.TVShow.Title") or
                    self._home.getProperty("TMDbHelper.ListItem.Title") or ""
                )
                info["imdb_id"] = self._home.getProperty("TMDbHelper.ListItem.IMDb_ID") or ""
                info["year"] = self._home.getProperty("TMDbHelper.ListItem.Year") or ""

        # 3. ListItem info labels — last resort
        if not info["title"]:
            info["title"] = (
                xbmc.getInfoLabel("ListItem.TVShowTitle") or
                xbmc.getInfoLabel("ListItem.Title") or ""
            )
            info["year"] = xbmc.getInfoLabel("ListItem.Year") or ""
            info["imdb_id"] = xbmc.getInfoLabel("ListItem.IMDBNumber") or ""
            dbtype = xbmc.getInfoLabel("ListItem.DBType") or ""
            if dbtype in ("episode", "tvshow", "season"):
                info["media_type"] = "series"
            elif not info["media_type"]:
                info["media_type"] = "movie"

        info["title"] = re.sub(r"\s*\(\d{4}\)\s*$", "", (info["title"] or "").strip())
        return info

    def _make_content_id(self, info):
        media = info.get("media_type") or "movie"
        tmdb_id = info.get("tmdb_id") or ""
        if tmdb_id:
            return "{}_{}".format(media, tmdb_id)
        return "{}_{}_{}".format(media, (info.get("title") or "").strip(), info.get("year") or "")

    def check_and_update(self):
        info = self._get_content_info()
        if not info.get("tmdb_id") and not info.get("title"):
            return

        content_id = self._make_content_id(info)
        if content_id == self._current_id:
            return

        # During playback, ignore TMDbHelper-driven changes (OSD cast list scrolling
        # changes TMDbHelper to show each actor — that must never replace the actual
        # playing content's images).
        if self._playing and self._current_id is not None and not info["_from_player"]:
            return

        log("Content changed: '{}' ({}, tmdb={})".format(
            info.get("title") or "(no title)", info.get("media_type"), info.get("tmdb_id", "")))

        mapping = self.cache.get_mapping(content_id)

        if mapping is None:
            mapping = {}
            raw = {}

            tvdb_client = self._get_tvdb_client()

            if tvdb_client and tvdb_client.api_key:
                tvdb_id, resolved_type = tvdb_client.resolve_tvdb_id(
                    info.get("tmdb_id"),
                    info.get("imdb_id"),
                    info.get("media_type", "movie"),
                    info.get("title"),
                    info.get("year"),
                )
                if tvdb_id:
                    if resolved_type == "series":
                        raw = tvdb_client.get_series_character_images(tvdb_id)
                        log("TVDB: {} images for series id={}".format(len(raw) // 2 if raw else 0, tvdb_id))
                    else:
                        raw = tvdb_client.get_movie_character_images(tvdb_id)
                        log("TVDB: {} images for movie id={}".format(len(raw) // 2 if raw else 0, tvdb_id))
                else:
                    log("TVDB: could not resolve id for '{}'".format(info.get("title")), xbmc.LOGWARNING)
            else:
                log("TVDB API key not set", xbmc.LOGWARNING)

            # TVMaze fallback for series when TVDB has few/no results (free, no key needed)
            if info.get("media_type") == "series" and len(raw) < 3 and info.get("title"):
                tvmaze_raw = self.tvmaze.get_character_images(
                    info["title"], imdb_id=info.get("imdb_id") or None
                )
                if tvmaze_raw:
                    log("TVMaze fallback: {} images for '{}'".format(
                        len(tvmaze_raw) // 2 if tvmaze_raw else 0, info["title"]))
                    for k, v in tvmaze_raw.items():
                        if k not in raw:
                            raw[k] = v

            for actor_name, img_url in raw.items():
                local = self.cache.get_local_image(img_url)
                if local:
                    mapping[actor_name] = local

            self.cache.save_mapping(content_id, mapping)
            log("Cached {} images for '{}'".format(len(mapping) // 2 if mapping else 0, info.get("title")))

        if mapping:
            count = self.active.populate(mapping)
            if count > 0:
                self._home.setProperty("charcast.active", "true")
                log("Active: {} character images ready".format(count))
            else:
                self.active.clear()
                self._home.clearProperty("charcast.active")
                log("No valid images placed in active/ — check cache", xbmc.LOGWARNING)
        else:
            self.active.clear()
            self._home.clearProperty("charcast.active")

        self._current_id = content_id

    def clear(self):
        self.active.clear()
        self._current_id = None
        self._home.clearProperty("charcast.active")


class PlayerMonitor(xbmc.Player):
    def __init__(self, cm):
        super().__init__()
        self.cm = cm

    def onAVStarted(self):
        log("Playback started")
        self.cm._playing = True
        xbmc.sleep(1500)
        self.cm._current_id = None
        self.cm.check_and_update()

    def onPlayBackStopped(self):
        self.cm._playing = False
        self.cm.clear()

    def onPlayBackEnded(self):
        self.cm._playing = False
        self.cm.clear()


class KodiMonitor(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.settings_changed = False

    def onSettingsChanged(self):
        self.settings_changed = True


def main():
    log("Service v5.3 starting (TVDB + TVMaze fallback)")

    addon = xbmcaddon.Addon("script.charactercast")
    if not addon.getSetting("tvdb_apikey"):
        log("No TVDB API key configured — will use TVMaze for series")

    # Patch Includes_CharacterCast.xml in the active skin.
    xbmc.sleep(2000)
    if _update_skin_file():
        xbmc.sleep(500)
        xbmc.executebuiltin("ReloadSkin()")

    monitor = KodiMonitor()
    cm = ContentMonitor()
    player = PlayerMonitor(cm)
    home = xbmcgui.Window(10000)
    last_tmdb_id = ""

    while not monitor.abortRequested():
        if monitor.waitForAbort(2):
            break

        if monitor.settings_changed:
            monitor.settings_changed = False
            cm.addon = xbmcaddon.Addon("script.charactercast")
            cm._tvdb_client = None

        try:
            current_tmdb_id = home.getProperty("TMDbHelper.ListItem.Monitor.TMDb_ID") or ""

            if player.isPlaying():
                # Sync last_tmdb_id so that when playback ends the browse-mode
                # check doesn't immediately re-trigger on a stale ID delta.
                last_tmdb_id = current_tmdb_id
                # Keep calling check_and_update() so images load even if
                # onAVStarted fired before the player had metadata ready.
                # The _from_player guard inside check_and_update() prevents
                # OSD cast-list scrolling from hijacking the content.
                cm.check_and_update()
            else:
                if current_tmdb_id != last_tmdb_id:
                    last_tmdb_id = current_tmdb_id
                    if current_tmdb_id:
                        cm._current_id = None
                        cm.check_and_update()

        except Exception as e:
            log("Error: {}".format(e))

    cm.clear()
    home.clearProperty("charcast.active")
    log("Service stopped")


if __name__ == "__main__":
    main()
