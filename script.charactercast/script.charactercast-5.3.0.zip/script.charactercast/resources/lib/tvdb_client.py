# -*- coding: utf-8 -*-
"""TVDB API v4 client — primary source for character images (series and movies)."""

import json
import os
import time

try:
    from urllib.request import Request, urlopen
    from urllib.error import HTTPError, URLError
    from urllib.parse import quote_plus
except ImportError:
    from urllib2 import Request, urlopen, HTTPError, URLError
    from urllib import quote_plus

import xbmc
import xbmcaddon
import xbmcvfs

BASE = "https://api4.thetvdb.com/v4"


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[CharacterCast][TVDB] {}".format(msg), level)


class TVDBClient:
    """TVDB API v4: login, resolve TVDB id, fetch character images for series/movies."""

    def __init__(self, api_key):
        self.api_key = (api_key or "").strip()
        self._token = None
        self._token_path = None
        self._last_request = 0.0

    def _token_file(self):
        if self._token_path is None:
            addon = xbmcaddon.Addon("script.charactercast")
            profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
            self._token_path = os.path.join(profile, "tvdb_token.txt")
        return self._token_path

    def _load_token(self):
        path = self._token_file()
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    return f.read().strip()
            except Exception:
                pass
        return None

    def _save_token(self, token):
        path = self._token_file()
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(token)
        except Exception as e:
            log("Could not save token: {}".format(e), xbmc.LOGWARNING)

    def _rate_limit(self):
        now = time.time()
        if now - self._last_request < 0.5:
            time.sleep(0.5 - (now - self._last_request))
        self._last_request = time.time()

    def login(self):
        """Obtain Bearer token; cache in addon_data. Returns token or None."""
        if not self.api_key:
            return None
        cached = self._load_token()
        if cached:
            self._token = cached
            return self._token
        self._rate_limit()
        try:
            req = Request(BASE + "/login")
            req.add_header("Content-Type", "application/json")
            req.add_header("Accept", "application/json")
            req.add_header("User-Agent", "Kodi CharacterCast/5.0")
            req.data = json.dumps({"apikey": self.api_key}).encode("utf-8")
            resp = urlopen(req, timeout=15)
            data = json.loads(resp.read().decode("utf-8"))
            token = (data.get("data") or {}).get("token")
            if token:
                self._token = token
                self._save_token(token)
                return token
        except HTTPError as e:
            if e.code == 401:
                log("TVDB login failed: invalid API key")
            else:
                log("TVDB login HTTP error: {}".format(e.code))
        except Exception as e:
            log("TVDB login error: {}".format(e))
        return None

    def _request(self, method, path, retry_unauthorized=True):
        """GET with Bearer token. On 401, re-login and retry once."""
        if not self._token:
            if not self.login():
                return None
        self._rate_limit()
        url = BASE + path
        try:
            req = Request(url)
            req.add_header("Authorization", "Bearer {}".format(self._token))
            req.add_header("Accept", "application/json")
            req.add_header("User-Agent", "Kodi CharacterCast/5.0")
            resp = urlopen(req, timeout=20)
            return json.loads(resp.read().decode("utf-8"))
        except HTTPError as e:
            if e.code == 401 and retry_unauthorized:
                self._token = None
                try:
                    os.remove(self._token_file())
                except Exception:
                    pass
                if self.login():
                    return self._request(method, path, retry_unauthorized=False)
            elif e.code == 404:
                log("Not found: {}".format(path))
            else:
                log("HTTP {}: {}".format(e.code, path))
            return None
        except Exception as e:
            log("Request error {}: {}".format(path, e))
            return None

    def resolve_tvdb_id(self, tmdb_id, imdb_id, media_type, title, year):
        """
        Resolve TVDB series/movie id from remote ids or search.
        Returns (tvdb_id, 'series'|'movie') or (None, None).
        """
        # Prefer IMDb for remote id lookup
        remote_id = None
        if imdb_id and (imdb_id.startswith("tt") or imdb_id.isdigit()):
            remote_id = imdb_id if imdb_id.startswith("tt") else "tt" + imdb_id
        if not remote_id and tmdb_id:
            remote_id = str(tmdb_id)
        if remote_id:
            data = self._request("GET", "/search/remoteid/{}".format(quote_plus(remote_id)))
            if data and data.get("data"):
                items = data["data"]
                if isinstance(items, list) and items:
                    for item in items:
                        itype = (item.get("type") or "").lower()
                        iid = item.get("id")
                        if iid is not None:
                            if media_type == "series" and itype == "series":
                                return (int(iid), "series")
                            if media_type == "movie" and itype == "movie":
                                return (int(iid), "movie")
                    for item in items:
                        itype = (item.get("type") or "").lower()
                        iid = item.get("id")
                        if iid is not None and itype in ("series", "movie"):
                            return (int(iid), itype)
                if isinstance(items, dict):
                    iid = items.get("id")
                    itype = (items.get("type") or "").lower() or media_type
                    if iid is not None:
                        return (int(iid), itype if itype in ("series", "movie") else media_type)
        # Fallback: text search
        query = title or ""
        if year and query:
            query = "{} {}".format(query, year)
        if not query.strip():
            return (None, None)
        stype = "series" if media_type == "series" else "movie"
        path = "/search?query={}&type={}".format(quote_plus(query.strip()), stype)
        data = self._request("GET", path)
        if data and data.get("data") and isinstance(data["data"], list) and data["data"]:
            first = data["data"][0]
            iid = first.get("id") or first.get("tvdb_id")
            if iid is not None:
                return (int(iid), stype)
        return (None, None)

    def _characters_to_mapping(self, characters):
        """Build {person_name_lower: image_url} from TVDB characters array."""
        mapping = {}
        for ch in characters or []:
            name = ch.get("personName") or ch.get("name") or ch.get("person_name")
            if not name:
                continue
            name = name.strip()
            if not name:
                continue
            url = ch.get("image") or ch.get("personImgURL") or ch.get("person_image")
            if isinstance(url, dict):
                url = url.get("url") or url.get("original") or url.get("medium")
            if not url or not isinstance(url, str):
                continue
            name_lower = name.lower()
            mapping[name_lower] = url
            if name != name_lower:
                mapping[name] = url
        return mapping

    def get_series_character_images(self, tvdb_id):
        """GET /series/{id}/extended, return {actor_name_lower: image_url}."""
        data = self._request("GET", "/series/{}/extended".format(tvdb_id))
        if not data or not data.get("data"):
            return {}
        extended = data["data"]
        chars = extended.get("characters") if isinstance(extended, dict) else None
        return self._characters_to_mapping(chars)

    def get_movie_character_images(self, tvdb_id):
        """GET /movies/{id}/extended, return {actor_name_lower: image_url}."""
        data = self._request("GET", "/movies/{}/extended".format(tvdb_id))
        if not data or not data.get("data"):
            return {}
        extended = data["data"]
        chars = extended.get("characters") if isinstance(extended, dict) else None
        return self._characters_to_mapping(chars)
