# -*- coding: utf-8 -*-
"""
Character Cast Images v5 — Background Service
TVDB API v4 = primary; TMDb headshots (via getCast()) = supplement for actors not covered by TVDB.
Character images written to: special://profile/addon_data/script.charactercast/active/actor name.jpg
Skin: $INFO[ListItem.Label,special://profile/addon_data/script.charactercast/active/,.jpg]
"""

import os
import re
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.tvdb_client import TVDBClient
from resources.lib.cache_manager import CacheManager
from resources.lib.active_images import ActiveImageManager


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[CharacterCast][Service] {}".format(msg), level)


# Skin XML written to Includes_CharacterCast.xml in the active skin.
# Player.HasVideo gates character images to OSD-only; info/browse pages fall
# through to the normal $VAR[Image_Poster] (TMDb actor headshots).
_CHARCAST_XML = (
    '<?xml version="1.0" encoding="UTF-8"?>\n'
    '<includes>\n'
    '    <!-- Each actor thumbnail in the OSD cast row.\n'
    '         FileExists($INFO[label,prefix,suffix]) fails to parse (commas in $INFO args\n'
    '         break the condition parser). $VAR inside FileExists also fails (conditions\n'
    '         evaluate $VAR as boolean, not string).\n'
    '         Solution: no FileExists. Actors WITH CharCast files show them; actors without\n'
    '         show blank tiles (background=true in Object_Layout_Image_Rectangle shows\n'
    '         the item background). When not playing, falls through to $VAR[Image_Poster]. -->\n'
    '    <variable name="Image_Poster_CharCast">\n'
    '        <value condition="!String.IsEmpty(Window(Home).Property(charcast.active))'
    ' + Player.HasVideo + [String.IsEqual(ListItem.DBType,actor)'
    ' | String.IsEqual(ListItem.Property(DBType),actor)]">'
    '$INFO[ListItem.Label,special://profile/addon_data/script.charactercast/active/,.jpg]'
    '</value>\n'
    '        <value>$VAR[Image_Poster]</value>\n'
    '    </variable>\n'
    '    <!-- OSD tray: big circle for the focused cast member.\n'
    '         When playing + charcast.active: returns CharCast path.\n'
    '         When CharCast file is missing, Object_InfoCircle_Image background=true reveals\n'
    '         the fallback_icon layer (set to ListItem.Icon in Custom_1141_OSD_Cast.xml).\n'
    '         When not playing: falls through to ListItem.Icon (TMDb headshot). -->\n'
    '    <variable name="Image_CharCast_Actor_OSD">\n'
    '        <value condition="!String.IsEmpty(Window(Home).Property(charcast.active))'
    ' + Player.HasVideo">'
    '$INFO[Container(6501).ListItem.Label,special://profile/addon_data/script.charactercast/active/,.jpg]'
    '</value>\n'
    '        <value>$INFO[Container(6501).ListItem.Icon]</value>\n'
    '    </variable>\n'
    '</includes>\n'
)


def _update_skin_file():
    """
    Find (or create) Includes_CharacterCast.xml inside the active skin and
    ensure Includes.xml references it.  Returns True if anything changed.
    """
    skin_id = xbmc.getSkinDir()
    if not skin_id:
        return False

    skin_path = xbmcvfs.translatePath("special://home/addons/{}/".format(skin_id))
    if not os.path.isdir(skin_path):
        log("Skin path not found: {}".format(skin_path), xbmc.LOGWARNING)
        return False

    target = None
    includes_dir = None
    for root, _dirs, files in os.walk(skin_path):
        if "Includes_CharacterCast.xml" in files:
            target = os.path.join(root, "Includes_CharacterCast.xml")
            if includes_dir is None:
                includes_dir = root
            break
        if "Includes.xml" in files and includes_dir is None:
            includes_dir = root

    if not target:
        if includes_dir:
            target = os.path.join(includes_dir, "Includes_CharacterCast.xml")
            log("Includes_CharacterCast.xml not found — will create at: {}".format(target))
        else:
            log("Could not find skin XML directory in '{}'".format(skin_id), xbmc.LOGWARNING)
            return False

    changed = False

    # --- 1. Write / update Includes_CharacterCast.xml ---
    try:
        with open(target, "r", encoding="utf-8") as f:
            current = f.read()
        if current.strip() == _CHARCAST_XML.strip():
            log("Skin file already up to date")
        else:
            raise IOError("content changed")
    except (IOError, OSError):
        try:
            with open(target, "w", encoding="utf-8") as f:
                f.write(_CHARCAST_XML)
            log("Updated skin Includes_CharacterCast.xml at: {}".format(target))
            changed = True
        except Exception as e:
            log("Failed to update skin file: {}".format(e), xbmc.LOGWARNING)
            return False

    # --- 2. Ensure Includes.xml references the CharacterCast file ---
    if includes_dir:
        includes_xml = os.path.join(includes_dir, "Includes.xml")
        try:
            with open(includes_xml, "r", encoding="utf-8") as f:
                inc_content = f.read()
            if "Includes_CharacterCast" not in inc_content:
                new_content = inc_content.replace(
                    "</includes>",
                    '    <include file="Includes_CharacterCast.xml" />\n</includes>'
                )
                with open(includes_xml, "w", encoding="utf-8") as f:
                    f.write(new_content)
                log("Added Includes_CharacterCast.xml reference to Includes.xml")
                changed = True
            else:
                log("Includes.xml already references Includes_CharacterCast.xml")
        except Exception as e:
            log("Could not patch Includes.xml: {}".format(e), xbmc.LOGWARNING)

    # --- 3. Patch Layout_Poster icon in Includes_Layouts.xml ---
    if includes_dir:
        layouts_xml = os.path.join(includes_dir, "Includes_Layouts.xml")
        if os.path.isfile(layouts_xml):
            try:
                with open(layouts_xml, "r", encoding="utf-8") as f:
                    layouts_content = f.read()
                patched = re.sub(
                    r'(<include name="Layout_Poster">.*?<param name="icon">)\$VAR\[Image_Poster\](</param>)',
                    r'\1$VAR[Image_Poster_CharCast]\2',
                    layouts_content,
                    flags=re.DOTALL,
                    count=1,
                )
                if patched != layouts_content:
                    with open(layouts_xml, "w", encoding="utf-8") as f:
                        f.write(patched)
                    log("Patched Layout_Poster icon in Includes_Layouts.xml")
                    changed = True
                else:
                    log("Includes_Layouts.xml already patched")
            except Exception as e:
                log("Could not patch Includes_Layouts.xml: {}".format(e), xbmc.LOGWARNING)

    return changed


class ContentMonitor:
    def __init__(self):
        self.addon = xbmcaddon.Addon("script.charactercast")
        self.cache = CacheManager()
        self._tvdb_client = None
        self.active = ActiveImageManager()
        self._current_id = None
        self._playing = False
        self._home = xbmcgui.Window(10000)

    def _get_tvdb_client(self):
        if self._tvdb_client is None:
            key = self.addon.getSetting("tvdb_apikey") or ""
            self._tvdb_client = TVDBClient(key) if key else None
        return self._tvdb_client

    def _get_content_info(self):
        info = {
            "title": "", "year": "", "media_type": "", "imdb_id": "", "tmdb_id": "",
            "_from_player": False,
        }

        # 1. Player API — always tried first during playback; gives stable detection
        # Guard with Player.HasVideo so getVideoInfoTag() is only called once the
        # video stream is actually rendering (avoids "not playing any videofile" spam
        # during the loading gap between isPlaying() and AV start).
        player = xbmc.Player()
        if player.isPlaying() and xbmc.getCondVisibility("Player.HasVideo"):
            try:
                tag = player.getVideoInfoTag()
                title = tag.getTVShowTitle() or tag.getTitle() or ""
                if title:
                    info["title"] = title
                    info["year"] = str(tag.getYear()) if tag.getYear() else ""
                    info["imdb_id"] = tag.getIMDBNumber() or ""
                    info["_from_player"] = True
                    try:
                        info["tmdb_id"] = tag.getUniqueID("tmdb") or ""
                    except Exception:
                        pass
                    if tag.getTVShowTitle() or tag.getMediaType() in ("episode", "tvshow", "season"):
                        info["media_type"] = "series"
                    else:
                        info["media_type"] = "movie"
            except Exception:
                pass

        # 2. TMDbHelper — used when not playing (browsing) or player has no metadata yet
        if not info["title"] and not info["tmdb_id"]:
            tmdb_type = self._home.getProperty("TMDbHelper.ListItem.Monitor.TMDb_Type") or ""
            tmdb_id = self._home.getProperty("TMDbHelper.ListItem.Monitor.TMDb_ID") or ""
            if tmdb_type and tmdb_id:
                info["tmdb_id"] = tmdb_id
                info["media_type"] = "series" if tmdb_type == "tv" else "movie"
                # For TV, prefer TVShow.Title and native TVShowTitle over episode Title
                if tmdb_type == "tv":
                    info["title"] = (
                        self._home.getProperty("TMDbHelper.ListItem.TVShow.Title") or
                        xbmc.getInfoLabel("ListItem.TVShowTitle") or
                        self._home.getProperty("TMDbHelper.ListItem.Title") or ""
                    )
                else:
                    info["title"] = self._home.getProperty("TMDbHelper.ListItem.Title") or ""
                info["imdb_id"] = self._home.getProperty("TMDbHelper.ListItem.IMDb_ID") or ""
                info["year"] = self._home.getProperty("TMDbHelper.ListItem.Year") or ""

        # 3. ListItem info labels — last resort
        if not info["title"]:
            info["title"] = (
                xbmc.getInfoLabel("ListItem.TVShowTitle") or
                xbmc.getInfoLabel("ListItem.Title") or ""
            )
            info["year"] = xbmc.getInfoLabel("ListItem.Year") or ""
            info["imdb_id"] = xbmc.getInfoLabel("ListItem.IMDBNumber") or ""
            dbtype = xbmc.getInfoLabel("ListItem.DBType") or ""
            if dbtype in ("episode", "tvshow", "season"):
                info["media_type"] = "series"
            elif not info["media_type"]:
                info["media_type"] = "movie"

        # For series with a tmdb_id, also ensure we have the show title (not an episode title).
        # If ListItem.TVShowTitle is populated and differs from what we have, prefer it.
        if info.get("media_type") == "series" and info.get("tmdb_id"):
            show_title = xbmc.getInfoLabel("ListItem.TVShowTitle") or ""
            if show_title and not info.get("title"):
                info["title"] = show_title

        info["title"] = re.sub(r"\s*\(\d{4}\)\s*$", "", (info["title"] or "").strip())
        return info

    def _make_content_id(self, info):
        media = info.get("media_type") or "movie"
        tmdb_id = info.get("tmdb_id") or ""
        if tmdb_id:
            return "{}_{}".format(media, tmdb_id)
        return "{}_{}_{}".format(media, (info.get("title") or "").strip(), info.get("year") or "")

    def check_and_update(self):
        info = self._get_content_info()
        if not info.get("tmdb_id") and not info.get("title"):
            return

        content_id = self._make_content_id(info)
        if content_id == self._current_id:
            return

        # During playback, ignore TMDbHelper-driven changes (OSD cast list scrolling
        # changes TMDbHelper to show each actor — that must never replace the actual
        # playing content's images).
        if self._playing and self._current_id is not None and not info["_from_player"]:
            return

        log("Content changed: '{}' ({}, tmdb={})".format(
            info.get("title") or "(no title)", info.get("media_type"), info.get("tmdb_id", "")))

        mapping = self.cache.get_mapping(content_id)

        if mapping is None:
            mapping = {}
            raw = {}

            tvdb_client = self._get_tvdb_client()

            if tvdb_client and tvdb_client.api_key:
                tvdb_id, resolved_type = tvdb_client.resolve_tvdb_id(
                    info.get("tmdb_id"),
                    info.get("imdb_id"),
                    info.get("media_type", "movie"),
                    info.get("title"),
                    info.get("year"),
                )
                if tvdb_id:
                    if resolved_type == "series":
                        raw = tvdb_client.get_series_character_images(tvdb_id)
                        log("TVDB: {} images for series id={}".format(len(raw) // 2 if raw else 0, tvdb_id))
                    else:
                        raw = tvdb_client.get_movie_character_images(tvdb_id)
                        log("TVDB: {} images for movie id={}".format(len(raw) // 2 if raw else 0, tvdb_id))
                else:
                    log("TVDB: could not resolve id for '{}'".format(info.get("title")), xbmc.LOGWARNING)
            else:
                log("TVDB API key not set", xbmc.LOGWARNING)

            for actor_name, img_url in raw.items():
                local = self.cache.get_local_image(img_url)
                if local:
                    mapping[actor_name] = local

            # Only cache non-empty results. Empty results are not saved so
            # the next encounter triggers a fresh fetch.
            if mapping:
                self.cache.save_mapping(content_id, mapping)
            log("Fetched {} images for '{}'".format(len(mapping) // 2 if mapping else 0, info.get("title")))

        # TMDb supplement only runs during active playback. During browsing, the TVDB
        # cache results are sufficient and fast. Running the full supplement on every
        # scroll change causes I/O storms (100–200+ symlink ops per content change).
        if not info.get("_from_player"):
            if mapping:
                count = self.active.populate(mapping)
                if count > 0:
                    self._home.setProperty("charcast.active", "true")
                else:
                    self.active.clear()
                    self._home.clearProperty("charcast.active")
            else:
                self.active.clear()
                self._home.clearProperty("charcast.active")
            self._current_id = content_id
            return

        # TMDb headshot supplement: queries TMDbHelper's local ItemDetails.db for cast
        # profile images. Works for plugin-played items (no Kodi library entry needed).
        try:
            import sqlite3 as _sqlite3
            tmdb_id_str = info.get("tmdb_id", "")
            media = info.get("media_type", "movie")

            placeholder = xbmcvfs.translatePath(
                "special://home/addons/plugin.video.themoviedb.helper/resources/icons/themoviedb/default.png"
            )
            if not os.path.isfile(placeholder):
                placeholder = ""

            if tmdb_id_str:
                tmdbhelper_profile = xbmcvfs.translatePath(
                    "special://profile/addon_data/plugin.video.themoviedb.helper/"
                )
                db_path = os.path.join(tmdbhelper_profile, "database_07", "ItemDetails.db")
                item_id = "{}.{}".format("tv" if media == "series" else "movie", tmdb_id_str)
                if os.path.isfile(db_path):
                    conn = _sqlite3.connect("file:{}?mode=ro".format(db_path), uri=True)
                    cur = conn.cursor()
                    # LEFT JOIN: include actors without a profile image (icon=None → placeholder)
                    cur.execute("""
                        SELECT p.name, a.icon
                        FROM castmember cm
                        JOIN person p ON p.tmdb_id = cm.tmdb_id
                        LEFT JOIN art a ON a.parent_id = p.id AND a.type = 'profiles'
                        WHERE cm.parent_id = ?
                        GROUP BY cm.tmdb_id
                        ORDER BY cm.ordering
                        LIMIT 100
                    """, (item_id,))
                    rows = cur.fetchall()
                    conn.close()
                    supplemented = 0
                    for name, icon in rows:
                        if not name:
                            continue
                        name_lower = name.lower()
                        if name_lower in mapping or name in mapping:
                            continue
                        if icon:
                            local = self.cache.get_local_image(
                                "https://image.tmdb.org/t/p/w185{}".format(icon)
                            )
                        else:
                            local = placeholder
                        if local:
                            mapping[name_lower] = local
                            if name != name_lower:
                                mapping[name] = local
                            supplemented += 1
                    if supplemented:
                        log("TMDb supplement added {} headshots".format(supplemented))

            # Episode guest star supplement: query TMDb episode credits API for
            # season/episode-specific cast not stored in TMDbHelper's show-level DB table.
            # Uses TMDbHelper's own embedded API key (read dynamically from its source file).
            if media == "series":
                try:
                    import re as _re
                    import json as _json
                    _player2 = xbmc.Player()
                    if _player2.isPlaying() and xbmc.getCondVisibility("Player.HasVideo"):
                        _tag2 = _player2.getVideoInfoTag()
                        _season = _tag2.getSeason()
                        _episode_num = _tag2.getEpisode()
                        if _season > 0 and _episode_num > 0:
                            _tmdb_key = ""
                            try:
                                _kf = os.path.join(
                                    xbmcvfs.translatePath(
                                        "special://home/addons/plugin.video.themoviedb.helper/"
                                    ),
                                    "resources/tmdbhelper/lib/api/api_keys/tmdb.py"
                                )
                                if os.path.isfile(_kf):
                                    with open(_kf, "r", encoding="utf-8") as _f:
                                        _km = _re.search(r"API_KEY\s*=\s*'([a-f0-9]+)'", _f.read())
                                        if _km:
                                            _tmdb_key = _km.group(1)
                            except Exception:
                                pass
                            if _tmdb_key:
                                from urllib.request import urlopen, Request as _URequest
                                _ep_url = (
                                    "https://api.themoviedb.org/3/tv/{}/season/{}/episode/{}"
                                    "/credits?api_key={}"
                                ).format(tmdb_id_str, _season, _episode_num, _tmdb_key)
                                try:
                                    _req = _URequest(_ep_url)
                                    _req.add_header("User-Agent", "Kodi CharacterCast/5.3.9")
                                    _ep_data = _json.loads(urlopen(_req, timeout=15).read())
                                    _ep_cast = _ep_data.get("cast", []) + _ep_data.get("guest_stars", [])
                                    _ep_added = 0
                                    for _actor in _ep_cast:
                                        _name = _actor.get("name", "")
                                        if not _name:
                                            continue
                                        _nl = _name.lower()
                                        if _nl in mapping or _name in mapping:
                                            continue
                                        _profile = _actor.get("profile_path", "")
                                        if _profile:
                                            _local = self.cache.get_local_image(
                                                "https://image.tmdb.org/t/p/w185{}".format(_profile))
                                        else:
                                            _local = placeholder
                                        if _local:
                                            mapping[_nl] = _local
                                            if _name != _nl:
                                                mapping[_name] = _local
                                            _ep_added += 1
                                    if _ep_added:
                                        log("Episode supplement: {} guest star(s) added for S{}E{}".format(
                                            _ep_added, _season, _episode_num))
                                except Exception as _ep_e:
                                    log("Episode TMDb API error: {}".format(_ep_e))
                except Exception:
                    pass

            # Placeholder pass: any actor in the OSD cast list still not covered.
            # getCast() returns a newline-separated string: "Actor as Character\n..."
            if placeholder:
                try:
                    _player = xbmc.Player()
                    if not _player.isPlaying():
                        raise Exception("not playing")
                    cast_str = _player.getVideoInfoTag().getCast()
                    if cast_str and isinstance(cast_str, str):
                        for line in cast_str.strip().split("\n"):
                            actor_name = line.split(" as ")[0].strip() if " as " in line else line.strip()
                            if not actor_name:
                                continue
                            name_lower = actor_name.lower()
                            if name_lower not in mapping and actor_name not in mapping:
                                mapping[name_lower] = placeholder
                                if actor_name != name_lower:
                                    mapping[actor_name] = placeholder
                except Exception:
                    pass

        except Exception as e:
            log("TMDb supplement error: {}".format(e))

        if mapping:
            count = self.active.populate(mapping)
            if count > 0:
                self._home.setProperty("charcast.active", "true")
                log("Active: {} character images ready".format(count))
            else:
                self.active.clear()
                self._home.clearProperty("charcast.active")
                log("No valid images placed in active/ — check cache", xbmc.LOGWARNING)
        else:
            self.active.clear()
            self._home.clearProperty("charcast.active")

        self._current_id = content_id

    def clear(self):
        self.active.clear()
        self._current_id = None
        self._home.clearProperty("charcast.active")


class PlayerMonitor(xbmc.Player):
    def __init__(self, cm):
        super().__init__()
        self.cm = cm

    def onAVStarted(self):
        log("Playback started")
        self.cm._playing = True
        xbmc.sleep(1500)
        self.cm._current_id = None
        self.cm.check_and_update()

    def onPlayBackStopped(self):
        self.cm._playing = False
        self.cm.clear()

    def onPlayBackEnded(self):
        self.cm._playing = False
        self.cm.clear()


class KodiMonitor(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.settings_changed = False

    def onSettingsChanged(self):
        self.settings_changed = True


def main():
    log("Service v5.3.9 starting (TVDB primary, TMDb supplement)")

    # Patch Includes_CharacterCast.xml in the active skin.
    xbmc.sleep(2000)
    if _update_skin_file():
        xbmc.sleep(500)
        xbmc.executebuiltin("ReloadSkin()")

    monitor = KodiMonitor()
    cm = ContentMonitor()
    player = PlayerMonitor(cm)
    home = xbmcgui.Window(10000)
    last_tmdb_id = ""

    while not monitor.abortRequested():
        if monitor.waitForAbort(2):
            break

        if monitor.settings_changed:
            monitor.settings_changed = False
            cm.addon = xbmcaddon.Addon("script.charactercast")
            cm._tvdb_client = None

        try:
            current_tmdb_id = home.getProperty("TMDbHelper.ListItem.Monitor.TMDb_ID") or ""

            if player.isPlaying():
                # Sync last_tmdb_id so that when playback ends the browse-mode
                # check doesn't immediately re-trigger on a stale ID delta.
                last_tmdb_id = current_tmdb_id
                # Keep calling check_and_update() so images load even if
                # onAVStarted fired before the player had metadata ready.
                # The _from_player guard inside check_and_update() prevents
                # OSD cast-list scrolling from hijacking the content.
                cm.check_and_update()
            else:
                if current_tmdb_id != last_tmdb_id:
                    last_tmdb_id = current_tmdb_id
                    if current_tmdb_id:
                        cm._current_id = None
                        cm.check_and_update()

        except Exception as e:
            log("Error: {}".format(e))

    cm.clear()
    home.clearProperty("charcast.active")
    log("Service stopped")


if __name__ == "__main__":
    main()
