# -*- coding: utf-8 -*-
"""
Active Image Manager
Creates a directory of character images named by actor name.
The skin references: special://profile/addon_data/script.charactercast/active/ActorName.jpg
"""

import os
import shutil

import xbmc
import xbmcaddon
import xbmcvfs


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[CharacterCast][Active] {}".format(msg), level)


class ActiveImageManager:
    """Manages the 'active' directory of currently-relevant character images."""

    def __init__(self):
        addon = xbmcaddon.Addon("script.charactercast")
        profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        self.active_dir = os.path.join(profile, "active")
        self._ensure_dir()

    def _ensure_dir(self):
        if not os.path.exists(self.active_dir):
            os.makedirs(self.active_dir)

    def clear(self):
        """Remove all images from the active directory."""
        if os.path.exists(self.active_dir):
            for f in os.listdir(self.active_dir):
                fp = os.path.join(self.active_dir, f)
                try:
                    os.remove(fp)
                except Exception:
                    pass

    def populate(self, mapping):
        """
        Populate the active directory with character images.
        mapping: {actor_name: local_cached_image_path}
        Files are named by the actor name (lowercase) so Kodi can look them up
        via $INFO[ListItem.Label,...].
        """
        self.clear()

        count = 0
        for actor_name, cached_path in mapping.items():
            if not cached_path or not os.path.exists(cached_path):
                continue

            safe_name = actor_name.strip()
            if not safe_name:
                continue

            dest = os.path.join(self.active_dir, "{}.jpg".format(safe_name))

            try:
                if os.path.exists(dest):
                    os.remove(dest)
                try:
                    os.symlink(cached_path, dest)
                except (OSError, AttributeError):
                    shutil.copy2(cached_path, dest)
                count += 1
            except Exception as e:
                log("Error creating active image for '{}': {}".format(safe_name, e))

        log("Populated {} active character images".format(count))
        return count
