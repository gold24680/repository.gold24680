# -*- coding: utf-8 -*-
"""TVMaze API Client — Free, no key required."""

import json
import time

try:
    from urllib.request import Request, urlopen
    from urllib.error import HTTPError, URLError
    from urllib.parse import quote_plus
except ImportError:
    from urllib2 import Request, urlopen, HTTPError, URLError
    from urllib import quote_plus

import xbmc

BASE = "https://api.tvmaze.com"


def log(msg, level=xbmc.LOGDEBUG):
    xbmc.log("[CharacterCast][TVMaze] {}".format(msg), level)


class TVMazeClient:
    def __init__(self):
        self._last = 0

    def _get(self, ep):
        now = time.time()
        if now - self._last < 0.5:
            time.sleep(0.5 - (now - self._last))
        self._last = time.time()
        try:
            req = Request(BASE + ep)
            req.add_header("Accept", "application/json")
            req.add_header("User-Agent", "Kodi CharacterCast/3.0")
            resp = urlopen(req, timeout=15)
            return json.loads(resp.read().decode("utf-8"))
        except HTTPError as e:
            if e.code == 429:
                time.sleep(5)
                try:
                    return json.loads(urlopen(Request(BASE + ep), timeout=15).read().decode("utf-8"))
                except Exception:
                    pass
            return None
        except Exception:
            return None

    def get_character_images(self, title, imdb_id=None):
        """Returns {lowercase_actor_name: character_image_url}"""
        show = None
        if imdb_id:
            show = self._get("/lookup/shows?imdb={}".format(imdb_id))
        if not show:
            results = self._get("/search/shows?q={}".format(quote_plus(title)))
            if results:
                best = results[0]
                for r in results:
                    if r.get("show", {}).get("name", "").lower().strip() == title.lower().strip():
                        best = r
                        break
                show = best.get("show")
        if not show or not show.get("id"):
            return {}

        cast = self._get("/shows/{}/cast".format(show["id"]))
        if not cast:
            return {}

        mapping = {}
        for entry in cast:
            person = entry.get("person", {})
            char = entry.get("character", {})
            name = (person.get("name") or "").strip()
            name_lower = name.lower()
            img = char.get("image")
            if name and img:
                url = img.get("original") or img.get("medium", "")
                if url:
                    # Store both lowercase and original case
                    mapping[name_lower] = url
                    if name != name_lower:
                        mapping[name] = url

        log("{} character images for '{}'".format(len(mapping) // 2, title))
        return mapping
