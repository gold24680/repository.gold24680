# -*- coding: utf-8 -*-
"""Cache Manager — stores character image mappings and downloaded images."""

import hashlib
import json
import os
import shutil
import time

try:
    from urllib.request import urlopen, Request
except ImportError:
    from urllib2 import urlopen, Request

import xbmc
import xbmcaddon
import xbmcvfs


def log(msg, level=xbmc.LOGDEBUG):
    xbmc.log("[CharacterCast][Cache] {}".format(msg), level)


class CacheManager:
    def __init__(self):
        addon = xbmcaddon.Addon("script.charactercast")
        profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        self.cache_dir = os.path.join(profile, "cache", "images")
        self.meta_dir = os.path.join(profile, "cache", "meta")
        self._ensure_dirs()
        self.cache_days = int(addon.getSetting("cache_days") or 30)

    def _ensure_dirs(self):
        for d in (self.cache_dir, self.meta_dir):
            if not os.path.exists(d):
                os.makedirs(d)

    @staticmethod
    def _key(text):
        return hashlib.md5(text.encode("utf-8")).hexdigest()

    def get_mapping(self, content_key):
        path = os.path.join(self.meta_dir, "{}.json".format(self._key(content_key)))
        if os.path.exists(path):
            if (time.time() - os.path.getmtime(path)) / 86400 < self.cache_days:
                try:
                    with open(path, "r", encoding="utf-8") as f:
                        return json.load(f)
                except Exception:
                    pass
        return None

    def save_mapping(self, content_key, mapping):
        path = os.path.join(self.meta_dir, "{}.json".format(self._key(content_key)))
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(mapping, f, ensure_ascii=False)
        except Exception as e:
            log("Save error: {}".format(e), xbmc.LOGWARNING)

    def get_local_image(self, url):
        """Download image if not cached, return local path."""
        if not url:
            return ""
        k = self._key(url)
        local = os.path.join(self.cache_dir, "{}.jpg".format(k))
        if os.path.exists(local):
            if (time.time() - os.path.getmtime(local)) / 86400 < self.cache_days:
                return local
        try:
            req = Request(url)
            req.add_header("User-Agent", "Kodi CharacterCast/3.0")
            data = urlopen(req, timeout=15).read()
            with open(local, "wb") as f:
                f.write(data)
            return local
        except Exception:
            return ""

    def clear_all(self):
        for d in (self.cache_dir, self.meta_dir):
            if os.path.exists(d):
                shutil.rmtree(d)
        self._ensure_dirs()

    def get_cache_size_mb(self):
        total = 0
        for d in (self.cache_dir, self.meta_dir):
            for root, _, files in os.walk(d):
                for f in files:
                    total += os.path.getsize(os.path.join(root, f))
        return round(total / (1024 * 1024), 2)
