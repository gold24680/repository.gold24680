# Character Cast Images for Kodi

Replace actor headshots with **character role images** from TheTVDB in your Kodi skin.

Instead of seeing Robert Pattinson's face, see **Batman**. Works for both **movies and TV shows**.

Built for **Arctic Fuse 3** skin with **TMDb Helper** — only changes images, everything else stays intact.

## What It Does

- Monitors what you're watching or browsing in Kodi
- Fetches character role images from the TVDB v4 API
- Replaces actor headshots with character images in cast lists
- Works in both the **info page** and **OSD** during playback
- All TMDb Helper functionality remains untouched (names, roles, actor click-through, episode cast)

## Requirements

- **Kodi 21 (Omega)** on CoreELEC (or any platform)
- **Arctic Fuse 3** skin
- **TMDb Helper** addon
- **TVDB API key** — get one at [thetvdb.com](https://thetvdb.com)

## Installation

### Step 1: Install the Addon

**Option A — From ZIP:**
1. Download `script.charactercast.zip` from [Releases](../../releases)
2. In Kodi: Settings → Add-ons → Install from zip file
3. Select the downloaded ZIP

**Option B — Manual copy via SMB:**
1. Copy the `script.charactercast` folder to `\\<your-box-ip>\Configfiles\addons\`
2. Restart Kodi
3. Enable: Settings → Add-ons → My Add-ons → Services → Character Cast Images

### Step 2: Enter Your TVDB API Key

1. Open addon settings: Settings → Add-ons → My Add-ons → Services → Character Cast Images → Configure
2. Enter your TVDB API key
3. (Optional) Enter your TVDB Subscriber PIN if you have one

### Step 3: Install Skin Files

Copy these 3 files from the `skin_files/` folder to your skin's `1080i` directory:

```
\\<your-box-ip>\Configfiles\addons\skin.arctic.fuse.3\1080i\
```

| File | Action |
|------|--------|
| `Includes_CharacterCast.xml` | **New file** — add to 1080i folder |
| `Includes.xml` | **Overwrite** existing file |
| `Includes_Layouts.xml` | **Overwrite** existing file |

### Step 4: Restart Kodi

Reboot or restart Kodi. Browse to any show or movie and check the cast list.

## How It Works

```
You browse to "The Batman" info page
         │
         ▼
Service detects TMDb Helper content change
         │
         ▼
TVDB API: search "The Batman" → get movie ID
         │
         ▼
TVDB API: get extended info → extract characters
  Robert Pattinson → Batman character image
  Zoë Kravitz → Catwoman character image
         │
         ▼
Downloads images to local cache
         │
         ▼
Creates active directory files:
  active/Robert Pattinson.jpg → Batman image
  active/Zoë Kravitz.jpg → Catwoman image
         │
         ▼
Skin variable picks up local file path
  → Shows Batman instead of Robert Pattinson!
```

TMDb Helper still serves the cast list with all metadata. Only the poster image is swapped.

## Skin Changes (Minimal)

Only 3 non-auto-generated files are modified:

- **`Includes_CharacterCast.xml`** — New file. Defines `Image_Poster_CharCast` variable
- **`Includes.xml`** — One line added to load the new file
- **`Includes_Layouts.xml`** — One word changed: `Layout_Poster` uses `Image_Poster_CharCast` instead of `Image_Poster`

The auto-generated `script-skinvariables-*.xml` files are NOT touched.

## Updating Remotely

To update the addon on your box without re-downloading ZIPs:

```bash
# SSH into your box
ssh root@<your-box-ip>

# Pull latest from GitHub
cd /storage/.kodi/addons/script.charactercast
git pull
```

Or just re-download the ZIP from Releases and reinstall.

## Troubleshooting

Check the Kodi log:
```bash
grep "CharacterCast" /storage/.kodi/temp/kodi.log | tail -20
```

**No character images:** Check your TVDB API key is entered in settings.

**Images not changing when browsing:** The service monitors `TMDbHelper.ListItem.Monitor.TMDb_ID` — it updates when you navigate between shows/movies in the info dialog.

**Skin looks broken:** Restore the original `Includes.xml` and `Includes_Layouts.xml` from the `skin_files/originals/` folder.

## License

GPL-2.0
