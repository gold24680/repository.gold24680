# -*- coding: utf-8 -*-
import sys
import xbmcaddon
import xbmcgui
from resources.lib.cache_manager import CacheManager


def main():
    args = sys.argv[1:] if len(sys.argv) > 1 else []
    action = args[0] if args else ""

    if action == "clear_cache":
        c = CacheManager()
        size = c.get_cache_size_mb()
        c.clear_all()
        xbmcgui.Dialog().notification("Character Cast",
            "Cache cleared ({} MB)".format(size), xbmcgui.NOTIFICATION_INFO, 3000)
    elif action == "test":
        addon = xbmcaddon.Addon("script.charactercast")
        apikey = addon.getSetting("tvdb_apikey")
        if not apikey:
            xbmcgui.Dialog().ok("Character Cast", "No TVDB API key. Enter it in settings.")
            return
        from resources.lib.tvdb_client import TVDBClient
        client = TVDBClient(apikey, addon.getSetting("tvdb_pin") or "")
        mapping = client.get_character_images("The Batman", media_type="movie", year="2022")
        if mapping:
            names = [n for n in mapping.keys() if n[0].isupper()][:5]
            msg = "TVDB API working!\n\nThe Batman (2022): {} actors\n\n{}".format(
                len(names), "\n".join(names))
            xbmcgui.Dialog().ok("Character Cast", msg)
        else:
            xbmcgui.Dialog().ok("Character Cast", "API connected but no character images found.")
    else:
        xbmcaddon.Addon("script.charactercast").openSettings()


if __name__ == "__main__":
    main()
