# -*- coding: utf-8 -*-
"""
Character Cast Images v5 — TVDB API Only
Monitors content changes. Fetches character images from TVDB.
Writes them to local files the skin reads directly.
"""

import os
import re
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.tvdb_client import TVDBClient
from resources.lib.cache_manager import CacheManager


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[CharacterCast][Service] {}".format(msg), level)


# Exact content for Includes_CharacterCast.xml in the skin.
# Player.HasVideo gates character images to OSD-only; info/browse pages fall
# through to the normal $VAR[Image_Poster] (TMDb actor headshots).
_CHARCAST_XML = (
    '<?xml version="1.0" encoding="UTF-8"?>\n'
    '<includes>\n'
    '    <variable name="Image_Poster_CharCast">\n'
    '        <value condition="!String.IsEmpty(Window(Home).Property(charcast.active))'
    ' + Player.HasVideo">'
    '$INFO[ListItem.Label,special://profile/addon_data/script.charactercast/active/,.jpg]'
    '</value>\n'
    '        <value>$VAR[Image_Poster]</value>\n'
    '    </variable>\n'
    '</includes>\n'
)


def _update_skin_file():
    """
    Find Includes_CharacterCast.xml inside the active skin and update it if
    the content has changed. Returns True if the file was changed.
    """
    skin_id = xbmc.getSkinDir()
    if not skin_id:
        return False

    skin_path = xbmcvfs.translatePath("special://home/addons/{}/".format(skin_id))
    if not os.path.isdir(skin_path):
        log("Skin path not found: {}".format(skin_path), xbmc.LOGWARNING)
        return False

    target = None
    for root, _dirs, files in os.walk(skin_path):
        if "Includes_CharacterCast.xml" in files:
            target = os.path.join(root, "Includes_CharacterCast.xml")
            break

    if not target:
        log("Includes_CharacterCast.xml not found in skin '{}'".format(skin_id),
            xbmc.LOGWARNING)
        return False

    try:
        with open(target, "r", encoding="utf-8") as f:
            current = f.read()
        if current.strip() == _CHARCAST_XML.strip():
            log("Skin file already up to date")
            return False
        with open(target, "w", encoding="utf-8") as f:
            f.write(_CHARCAST_XML)
        log("Updated skin Includes_CharacterCast.xml at: {}".format(target))
        return True
    except Exception as e:
        log("Failed to update skin file: {}".format(e), xbmc.LOGWARNING)
        return False


class ContentMonitor:
    def __init__(self):
        self.addon = xbmcaddon.Addon("script.charactercast")
        self.cache = CacheManager()
        self._client = None
        self._current_id = None
        self._playing = False
        self._home = xbmcgui.Window(10000)

    @property
    def client(self):
        apikey = self.addon.getSetting("tvdb_apikey")
        if not apikey:
            return None
        pin = self.addon.getSetting("tvdb_pin") or ""
        if self._client is None or self._client.apikey != apikey:
            self._client = TVDBClient(apikey, pin)
        return self._client

    def _get_content_info(self):
        """
        Detect what content is currently relevant.

        Priority order:
          1. Player API  — stable "what is actually playing"; flagged _from_player=True
          2. TMDbHelper  — used when player API returns nothing (metadata not loaded
                          yet) or when not playing (library browsing)
          3. ListItem info labels — last resort

        The _from_player flag lets check_and_update() avoid switching away from
        already-loaded content just because the user scrolled the OSD cast list
        (which changes TMDbHelper properties without changing what's playing).
        """
        info = {
            "title": "", "year": "", "media_type": "",
            "imdb_id": "", "tmdb_id": "", "_from_player": False,
        }

        # 1. Player API (always tried first; gives stable detection during playback)
        player = xbmc.Player()
        if player.isPlaying():
            try:
                tag = player.getVideoInfoTag()
                title = tag.getTVShowTitle() or tag.getTitle() or ""
                if title:
                    info["title"] = title
                    info["year"] = str(tag.getYear()) if tag.getYear() else ""
                    info["imdb_id"] = tag.getIMDBNumber() or ""
                    info["_from_player"] = True
                    try:
                        info["tmdb_id"] = tag.getUniqueID("tmdb") or ""
                    except Exception:
                        pass
                    if tag.getTVShowTitle() or tag.getMediaType() in ("episode", "tvshow", "season"):
                        info["media_type"] = "series"
                    else:
                        info["media_type"] = "movie"
            except Exception:
                pass

        # 2. TMDbHelper (fallback when player API is empty, or primary when browsing)
        if not info["title"] and not info["tmdb_id"]:
            tmdb_type = self._home.getProperty("TMDbHelper.ListItem.Monitor.TMDb_Type") or ""
            tmdb_id = self._home.getProperty("TMDbHelper.ListItem.Monitor.TMDb_ID") or ""

            if tmdb_type and tmdb_id:
                info["tmdb_id"] = tmdb_id
                info["media_type"] = "series" if tmdb_type == "tv" else "movie"
                info["title"] = (
                    self._home.getProperty("TMDbHelper.ListItem.TVShow.Title") or
                    self._home.getProperty("TMDbHelper.ListItem.Title") or ""
                )
                info["imdb_id"] = self._home.getProperty("TMDbHelper.ListItem.IMDb_ID") or ""
                info["year"] = self._home.getProperty("TMDbHelper.ListItem.Year") or ""

        # 3. ListItem info labels (last resort)
        if not info["title"]:
            info["title"] = (
                xbmc.getInfoLabel("ListItem.TVShowTitle") or
                xbmc.getInfoLabel("ListItem.Title") or ""
            )
            info["year"] = xbmc.getInfoLabel("ListItem.Year") or ""
            info["imdb_id"] = xbmc.getInfoLabel("ListItem.IMDBNumber") or ""
            dbtype = xbmc.getInfoLabel("ListItem.DBType") or ""
            if dbtype in ("episode", "tvshow", "season"):
                info["media_type"] = "series"
            elif not info["media_type"]:
                info["media_type"] = "movie"

        info["title"] = re.sub(r"\s*\(\d{4}\)\s*$", "", info["title"]).strip()
        return info

    def _make_id(self, info):
        return "{}_{}_{}".format(
            info["media_type"], info["tmdb_id"] or info["title"], info["year"]
        )

    def check_and_update(self):
        if not self.client:
            return

        info = self._get_content_info()
        if not info["title"] and not info["tmdb_id"]:
            if self._current_id is not None:
                self.clear()
            return

        content_id = self._make_id(info)
        if content_id == self._current_id:
            return

        # During active playback, only switch away from already-loaded content
        # if the detection came from the player API (what's actually playing).
        # Ignore TMDbHelper-driven changes — those happen when scrolling the OSD
        # cast list and should never clear the current show's character images.
        if self._playing and self._current_id is not None and not info["_from_player"]:
            return

        log("Content: '{}' ({}, tmdb={})".format(
            info["title"], info["media_type"], info.get("tmdb_id", "")))

        local_mapping = self.cache.get_mapping(content_id)

        # If cache hit but all local image files have been deleted from disk,
        # treat it as a cache miss so we re-fetch from TVDB instead of silently
        # showing nothing.
        if local_mapping and not any(
            p and os.path.exists(p) for p in local_mapping.values()
        ):
            log("Cached image files missing from disk — re-fetching", xbmc.LOGWARNING)
            local_mapping = None

        if local_mapping is None:
            tvdb_type = "series" if info["media_type"] == "series" else "movie"

            raw = self.client.get_character_images(
                info["title"],
                media_type=tvdb_type,
                year=info["year"] or None,
                imdb_id=info["imdb_id"] or None,
            )

            local_mapping = self.cache.download_all(raw)
            self.cache.save_mapping(content_id, local_mapping)
            log("Cached {} images for '{}'".format(len(local_mapping), info["title"]))

        if local_mapping:
            count = self.cache.populate_active(local_mapping)
            if count > 0:
                self._home.setProperty("charcast.active", "true")
                log("Active: {} character images ready".format(count))
            else:
                # populate returned 0 — all paths in the mapping are broken
                self.cache.clear_active()
                self._home.clearProperty("charcast.active")
                log("No valid images could be placed in active/ — check cache",
                    xbmc.LOGWARNING)
        else:
            self.cache.clear_active()
            self._home.clearProperty("charcast.active")

        self._current_id = content_id

    def clear(self):
        self.cache.clear_active()
        self._current_id = None
        self._home.clearProperty("charcast.active")


class PlayerMonitor(xbmc.Player):
    def __init__(self, cm):
        super().__init__()
        self.cm = cm

    def onAVStarted(self):
        log("Playback started")
        self.cm._playing = True
        xbmc.sleep(1500)
        self.cm._current_id = None
        self.cm.check_and_update()

    def onPlayBackStopped(self):
        self.cm._playing = False
        self.cm.clear()

    def onPlayBackEnded(self):
        self.cm._playing = False
        self.cm.clear()


class KodiMonitor(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.settings_changed = False

    def onSettingsChanged(self):
        self.settings_changed = True


def main():
    log("Service v5 starting (TVDB API)")

    addon = xbmcaddon.Addon("script.charactercast")
    if not addon.getSetting("tvdb_apikey"):
        log("No TVDB API key configured — waiting for settings")

    # Patch Includes_CharacterCast.xml in the active skin to enforce OSD-only
    # character images. Only reloads the skin if the file actually changed.
    xbmc.sleep(2000)
    if _update_skin_file():
        xbmc.sleep(500)
        xbmc.executebuiltin("ReloadSkin()")

    monitor = KodiMonitor()
    cm = ContentMonitor()
    player = PlayerMonitor(cm)
    home = xbmcgui.Window(10000)
    last_tmdb_id = ""

    while not monitor.abortRequested():
        if monitor.waitForAbort(2):
            break

        if monitor.settings_changed:
            monitor.settings_changed = False
            cm.addon = xbmcaddon.Addon("script.charactercast")
            cm._client = None

        try:
            current_tmdb_id = home.getProperty("TMDbHelper.ListItem.Monitor.TMDb_ID") or ""

            if player.isPlaying():
                # Sync last_tmdb_id so that when playback ends, the browse-mode
                # check doesn't immediately re-trigger on a stale ID delta.
                last_tmdb_id = current_tmdb_id
                # Keep calling check_and_update() so images load even if
                # onAVStarted fired before the player had metadata ready.
                cm.check_and_update()
            else:
                if current_tmdb_id != last_tmdb_id:
                    last_tmdb_id = current_tmdb_id
                    if current_tmdb_id:
                        cm._current_id = None
                        cm.check_and_update()

        except Exception as e:
            log("Error: {}".format(e))

    cm.clear()
    home.clearProperty("charcast.active")
    log("Service stopped")


if __name__ == "__main__":
    main()
