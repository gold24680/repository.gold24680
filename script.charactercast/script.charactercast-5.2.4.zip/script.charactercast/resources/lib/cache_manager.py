# -*- coding: utf-8 -*-
"""Cache Manager — stores character image mappings and downloaded images."""

import hashlib
import json
import os
import shutil
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

try:
    from urllib.request import urlopen, Request
except ImportError:
    from urllib2 import urlopen, Request

import xbmc
import xbmcaddon
import xbmcvfs


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[CharacterCast][Cache] {}".format(msg), level)


# Minimum file size in bytes — anything smaller is a gray placeholder
_MIN_IMAGE_BYTES = 5000


class CacheManager:
    def __init__(self):
        addon = xbmcaddon.Addon("script.charactercast")
        profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        self.cache_dir = os.path.join(profile, "cache", "images")
        self.meta_dir = os.path.join(profile, "cache", "meta")
        self.active_dir = os.path.join(profile, "active")
        self._ensure_dirs()
        self.cache_days = int(addon.getSetting("cache_days") or 30)

    def _ensure_dirs(self):
        for d in (self.cache_dir, self.meta_dir, self.active_dir):
            if not os.path.exists(d):
                os.makedirs(d)

    @staticmethod
    def _key(text):
        return hashlib.md5(text.encode("utf-8")).hexdigest()

    # --- Metadata cache ---
    def get_mapping(self, content_key):
        path = os.path.join(self.meta_dir, "{}.json".format(self._key(content_key)))
        if os.path.exists(path):
            if (time.time() - os.path.getmtime(path)) / 86400 < self.cache_days:
                try:
                    with open(path, "r", encoding="utf-8") as f:
                        return json.load(f)
                except Exception:
                    pass
        return None

    def save_mapping(self, content_key, mapping):
        path = os.path.join(self.meta_dir, "{}.json".format(self._key(content_key)))
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(mapping, f, ensure_ascii=False)
        except Exception as e:
            log("Save error: {}".format(e), xbmc.LOGWARNING)

    # --- Image download cache ---
    def get_local_image(self, url):
        if not url:
            return ""
        k = self._key(url)
        local = os.path.join(self.cache_dir, "{}.jpg".format(k))
        if os.path.exists(local):
            if (time.time() - os.path.getmtime(local)) / 86400 < self.cache_days:
                return local
        try:
            req = Request(url)
            req.add_header("User-Agent", "Kodi CharacterCast/5.0")
            data = urlopen(req, timeout=15).read()
            # Reject gray placeholders — real character images are never this small
            if len(data) < _MIN_IMAGE_BYTES:
                log("Skipping placeholder image ({}B): {}".format(len(data), url[:60]),
                    xbmc.LOGDEBUG)
                return ""
            with open(local, "wb") as f:
                f.write(data)
            return local
        except Exception as e:
            log("Download failed {}: {}".format(url[:50], e), xbmc.LOGWARNING)
            return ""

    def download_all(self, url_mapping):
        """
        Download all character image URLs in parallel.
        url_mapping: {actor_name: image_url}
        Returns: {actor_name: local_path} for successfully downloaded images only.
        """
        if not url_mapping:
            return {}
        result = {}
        with ThreadPoolExecutor(max_workers=8) as executor:
            futures = {
                executor.submit(self.get_local_image, url): name
                for name, url in url_mapping.items()
            }
            for future in as_completed(futures):
                name = futures[future]
                try:
                    path = future.result()
                    if path:
                        result[name] = path
                except Exception as e:
                    log("Download error for '{}': {}".format(name, e), xbmc.LOGWARNING)
        return result

    # --- Active directory (current show/movie character images) ---
    def clear_active(self):
        if os.path.exists(self.active_dir):
            for f in os.listdir(self.active_dir):
                try:
                    os.remove(os.path.join(self.active_dir, f))
                except Exception:
                    pass

    def populate_active(self, mapping):
        """
        Populate active dir with character images named by actor name.
        mapping: {actor_name: local_cached_image_path}
        Creates symlinks/copies so the skin can find them by name.
        """
        self.clear_active()
        count = 0
        for actor_name, cached_path in mapping.items():
            if not cached_path or not os.path.exists(cached_path):
                continue
            name = actor_name.strip()
            if not name:
                continue
            dest = os.path.join(self.active_dir, "{}.jpg".format(name))
            try:
                if os.path.exists(dest):
                    os.remove(dest)
                try:
                    os.symlink(cached_path, dest)
                except (OSError, AttributeError):
                    shutil.copy2(cached_path, dest)
                count += 1
            except Exception as e:
                log("Active image error for '{}': {}".format(name, e), xbmc.LOGWARNING)
        return count

    # --- Cleanup ---
    def clear_all(self):
        for d in (self.cache_dir, self.meta_dir, self.active_dir):
            if os.path.exists(d):
                shutil.rmtree(d)
        self._ensure_dirs()

    def get_cache_size_mb(self):
        total = 0
        for d in (self.cache_dir, self.meta_dir):
            for root, _, files in os.walk(d):
                for f in files:
                    total += os.path.getsize(os.path.join(root, f))
        return round(total / (1024 * 1024), 2)
