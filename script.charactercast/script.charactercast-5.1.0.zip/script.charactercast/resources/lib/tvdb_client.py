# -*- coding: utf-8 -*-
"""
TVDB API v4 Client
Handles authentication, searching, and fetching character role images.
Works for both movies and TV shows.
"""

import json
import time

try:
    from urllib.request import Request, urlopen
    from urllib.error import HTTPError, URLError
    from urllib.parse import quote_plus
except ImportError:
    from urllib2 import Request, urlopen, HTTPError, URLError
    from urllib import quote_plus

import xbmc

BASE = "https://api4.thetvdb.com/v4"
TOKEN_LIFETIME = 86400  # 24 hours


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[CharacterCast][TVDB] {}".format(msg), level)


class TVDBClient:
    def __init__(self, apikey, pin=""):
        self.apikey = apikey
        self.pin = pin
        self._token = None
        self._token_time = 0

    def _authenticate(self):
        now = time.time()
        if self._token and (now - self._token_time) < TOKEN_LIFETIME:
            return True

        payload = {"apikey": self.apikey}
        if self.pin:
            payload["pin"] = self.pin

        data = self._post("/login", payload)
        if data and "data" in data and "token" in data["data"]:
            self._token = data["data"]["token"]
            self._token_time = now
            log("Authenticated successfully")
            return True

        log("Authentication FAILED", xbmc.LOGERROR)
        return False

    def _post(self, endpoint, payload):
        url = BASE + endpoint
        body = json.dumps(payload).encode("utf-8")
        req = Request(url, data=body)
        req.add_header("Content-Type", "application/json")
        req.add_header("Accept", "application/json")
        return self._do_request(req)

    def _get(self, endpoint):
        if not self._authenticate():
            return None
        url = BASE + endpoint
        req = Request(url)
        req.add_header("Accept", "application/json")
        req.add_header("Authorization", "Bearer {}".format(self._token))
        return self._do_request(req)

    @staticmethod
    def _do_request(req, retries=2):
        for attempt in range(retries + 1):
            try:
                resp = urlopen(req, timeout=15)
                return json.loads(resp.read().decode("utf-8"))
            except HTTPError as e:
                log("HTTP {} for {}".format(e.code, req.full_url), xbmc.LOGWARNING)
                if e.code == 401 and attempt < retries:
                    time.sleep(1)
                    continue
                return None
            except Exception as e:
                log("Request error: {}".format(e), xbmc.LOGWARNING)
                if attempt < retries:
                    time.sleep(1)
                    continue
                return None
        return None

    def search(self, title, media_type="movie", year=None):
        """Search TVDB. media_type: 'movie' or 'series'."""
        params = "query={}&type={}".format(quote_plus(title), media_type)
        if year:
            params += "&year={}".format(year)
        data = self._get("/search?{}".format(params))
        if not data or "data" not in data:
            return []
        return data["data"]

    # URL substrings that indicate a gray placeholder rather than a real character image
    _PLACEHOLDER_PATTERNS = ("person-0", "/missing/", "placeimage", "person_placeholder",
                             "cast-placeholder", "no_person")

    def _get_characters(self, endpoint):
        """Fetch extended info and extract characters with role images."""
        data = self._get(endpoint)
        if not data or "data" not in data:
            return {}

        characters = data["data"].get("characters", [])
        mapping = {}

        for char in characters:
            char_type = char.get("type", 0)
            # Type 3 = Actor, Type 4 = Guest Star, 0 = unspecified
            if char_type not in (0, 3, 4):
                continue

            actor_name = (char.get("personName") or "").strip()
            char_image = char.get("image") or ""

            if not actor_name or not char_image:
                continue

            # Skip known gray placeholder URLs — fall back to TMDb image instead
            img_lower = char_image.lower()
            if any(p in img_lower for p in self._PLACEHOLDER_PATTERNS):
                continue

            # Store both original case and lowercase for matching
            mapping[actor_name] = char_image
            lower = actor_name.lower()
            if lower != actor_name:
                mapping[lower] = char_image

        return mapping

    def get_character_images(self, title, media_type="movie", year=None, imdb_id=None):
        """
        Search for content and return character images.
        Returns: {actor_name: character_image_url, ...}
        Both original case and lowercase keys are included.
        """
        if not self._authenticate():
            return {}

        results = self.search(title, media_type, year)
        if not results:
            # Try without year
            if year:
                results = self.search(title, media_type)
            if not results:
                log("No TVDB results for '{}' ({})".format(title, media_type))
                return {}

        # Find best match
        best = results[0]
        title_lower = title.lower().strip()
        for r in results:
            name = (r.get("name") or "").lower().strip()
            r_year = str(r.get("year", ""))
            if name == title_lower:
                if year and r_year == str(year):
                    best = r
                    break
                best = r

        # Get the object ID and type
        obj_type = best.get("type", media_type)
        tvdb_id = best.get("tvdb_id") or best.get("id", "")

        # For search results, extract the specific ID
        if obj_type == "movie":
            obj_id = best.get("movie_id") or best.get("tvdb_id") or best.get("id", "")
            endpoint = "/movies/{}/extended".format(obj_id)
        else:
            obj_id = best.get("series_id") or best.get("tvdb_id") or best.get("id", "")
            endpoint = "/series/{}/extended".format(obj_id)

        log("Best match: '{}' (ID={}, type={})".format(
            best.get("name", title), obj_id, obj_type))

        mapping = self._get_characters(endpoint)
        log("{} character images for '{}' ({})".format(
            len(mapping) // 2 if mapping else 0, title, media_type))

        return mapping
